import React from "react";
import "../styles/ThreeItems.css";
export const ThreeItems = () => {
  return (
    <div className="three-items">
      <div className="item-card">
        <div className="card-down">
          <img src="assets/icons/IDC.png" alt="" />
          <p>
            Hexnode is listed as a leader and a major player in IDC MarketScape
            UEM Vendors Assessment Reports 2024.
          </p>
        </div>

        <div className="stLine"></div>
      </div>

      <div className="item-card">
        <div className="card-down">
          <img src="assets/icons/Gartner.png" alt="" />
          <p>
            Hexnode is listed as a leader and a major player in IDC MarketScape
            UEM Vendors Assessment Reports 2024.
          </p>
        </div>

        <div className="stLine"></div>
      </div>

      <div className="item-card">
        <div className="card-down">
          <img src="assets/icons/Forrester.png" alt="" />
          <p>
            Hexnode is listed as a leader and a major player in IDC MarketScape
            UEM Vendors Assessment Reports 2024.
          </p>
        </div>
      </div>
    </div>
  );
};
