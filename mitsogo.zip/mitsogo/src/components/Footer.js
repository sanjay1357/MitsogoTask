import React from 'react'
import '../styles/Footer.css'

export const Footer = () => {
  return (
    <div className='footer'>
      <div className='foot-first'>
        <p className='hexnode-free'>Sign up and try Hexnode free for 14 days! </p>
        <div className='foot-input'>
          <input type='text' className='foot-box' placeholder='Your Work Email'/>
          <button className='get-started'>GET STARTED</button>
        </div>
        <div><span className='credit-card'>No credit cards required</span><span className='req-demo'>Request a demo</span>
        <img className='demo-ic' src='assets/icons/demo-ic.png' alt='' /></div>
      </div>
      <div className='foot-second'>
        <p>Terms of Use - Privacy - Cookies</p>
        <p>Copyright @ 2025 Mitsogo Inc All rights Reserved</p>
      </div>
    </div>
  )
}
