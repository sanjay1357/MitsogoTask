import React from 'react'
import '../styles/Header.css'
export const Header = () => {
  return (
    <div>
    <div className='headers'>
    <img width={"121px"} height={25} src='assets/icons/hex__logo.png' alt='' />
    <p className='get-started1'>14 DAY FREE TRAIL</p>
    </div>
    </div>
  )
}
