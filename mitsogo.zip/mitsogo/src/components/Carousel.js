import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Navigation, Pagination } from "swiper/modules";
import '../styles/Carousel.css'
import { Autoplay } from "swiper/modules";
import Marquee from "react-fast-marquee";

const Carousel = () => {
  const partners = [
    "assets/images/Background.png",
    "assets/images/List.png",
    "assets/images/Background.png",
    "assets/images/List.png",
    "assets/images/Background.png",
    "assets/images/List.png",
    "assets/images/Background.png",
    "assets/images/List.png",
    "assets/images/Background.png",
    "assets/images/List.png",
    "assets/images/Background.png",
    "assets/images/List.png",
  ];
  return (
    <div className="swipe-comp">
    <Swiper
   navigation
   modules={[Autoplay, Navigation]}
   className="mySwiper"
    >
      <SwiperSlide><img src="assets/images/List.png" alt="Slide 1" /></SwiperSlide>
      <SwiperSlide><img src="assets/images/Background.png" alt="Slide 1" /></SwiperSlide>
      <SwiperSlide><img src="assets/images/List.png" alt="Slide 1" /></SwiperSlide>
    </Swiper>

    <div className="w-full overflow-hidden bg-gray-100 py-4 mark">
      <Marquee speed={200} gradient={false}>
        {partners.map((logo, index) => (
          <img width={170} height={80} key={index} src={logo} alt="Partner Logo" className="h-16 mx-4" />
        ))}
      </Marquee>
    </div>
    </div>
  );
};

export default Carousel;
