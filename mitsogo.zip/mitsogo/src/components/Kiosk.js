import React from 'react'
import '../styles/Kiosk.css'
export const Kiosk = () => {
  return (
    <div className='kiosk'>
     <p className='mode-offer'>What additional possibilities does the Kiosk mode offer?</p>
     <div className='kiosk-flex'>
      <div className='kiosk-img'>
        <img width="100%" height="100%" src='assets/images/kiosk.png' alt='' />
      </div>
      <div className='kiosk-desc'>
          <p className='effort-less'>Effortless kiosk deployment & management</p>
          <p className='deploy'>Deploy kiosk-enabled devices straight out of the box. Flash a custom Android Enterprise, Samsung Knox or ROM with Hexnode App on the devices by collaborating with OEM vendors who provide specially configured ROMs.</p>
        <button className='try-free'>TRY FOR FREE <img src='assets/icons/demo-ic.png' alt='' /></button>
        <p className='kiosk-txt'>Customized interface for brand visibility</p>
        <p className='kiosk-txt'>What more can you do with Hexnode kiosk?</p>
        <p className='kiosk-txt'>Secure and update your app ecosystem</p>
        <p className='kiosk-txt'>Provide an easy-to-use interface for end-users</p>
       
        </div>
     </div>
    </div>
  )
}
