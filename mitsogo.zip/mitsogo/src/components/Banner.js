import React from 'react'
import '../styles/Banner.css'
export const Banner = () => {
  return (
    <div className='banner'>

    <div className='banner-btm'> 
      <div>
        <p className='turn-device'>Turn your devices into kiosks in a few minutes with Hexnode UEM</p>
      <div className='foot-input'>
          <input type='text' className='foot-box' placeholder='Your Work Email'/>
          <button className='get-started'>GET STARTED NOW</button>
        </div>
      </div>
      <div className='banner-mobile'>
        <img src='assets/images/Mobile.png' alt='' />
      </div>
       </div>
    </div>
  )
}
