import React from "react";
import "../styles/Modes.css";
export const Modes = () => {
  return (
    <div className="modes">
      <p className="specific-models">
        Specific kiosk modes for unique use cases
      </p>
      <img className="bg-img" src="assets/images/Background.png" alt="" />
    </div>
  );
};
