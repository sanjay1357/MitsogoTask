import React from 'react'
import '../styles/Platform.css'
export const Platform = () => {
  return (
    <div className='platfrom'>
      <p className='plat-sup'>Platforms Supported</p>
      <div className='platform-img'>
       <img src='assets/icons/Android.png' alt='' />
       <img src='assets/icons/Windows.png' alt='' />
       <img src='assets/icons/iOS.png' alt='' />
       <img src='assets/icons/android-tv.png' alt='' />
       <img src='assets/icons/Apple-Tv.png' alt='' />
       <img src='assets/icons/Amazon-Fire.png' alt='' />
      </div>
    </div>
  )
}
