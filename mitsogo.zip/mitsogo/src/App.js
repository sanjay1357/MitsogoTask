import "./App.css";
import { Banner } from "./components/Banner";
import Carousel from "./components/Carousel";
import { Footer } from "./components/Footer";
import { Header } from "./components/Header";
import { Kiosk } from "./components/Kiosk";
import { Modes } from "./components/Modes";
import { Platform } from "./components/Platform";
import { ThreeItems } from "./components/ThreeItems";

function App() {
  return (
    <div className="App">
      <Header />
      <Banner />
      <ThreeItems />
      <Modes />
      <Kiosk />
      <Carousel />
      <Platform />
      <Footer />
    </div>
  );
}

export default App;
